*****************************************************************

      pyfb - A Python Interface to the facebook Graph API

*****************************************************************

This is an Easy to Use Python Interface to the Facebook Graph API

It gives you methods to access your data on facebook and
provides objects instead of json dictionaries!

*****************************************************************

Dependencies

- simplejson
